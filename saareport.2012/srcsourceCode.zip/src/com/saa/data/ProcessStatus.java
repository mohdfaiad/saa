/*
 * ProcessStatus.java
 *
 * Created on April 23, 2007, 5:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.data;

/**
 *
 * @author Administrator
 */
public class ProcessStatus {
    
    /** Creates a new instance of ProcessStatus */
    public static String SUCCESS = "success";
    public static String FAIL    = "fail";
    private ProcessStatus() {
    }
    
}
