/*
 * UICollections.java
 *
 * Created on 21 ����¹ 2550, 9:51 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.data.ui;

/**
 *
 * @author Administrator
 */
public class UICollections {
   public static String [] years = {"2007","2008","2009","2010"};
   public static String [] months = {"January","Febuary","March","April",
    "May", "June", "July" , "August" ,"September" ,
    "October" ,"November", "December"}; 
    /** Creates a new instance of UICollections */
    public UICollections() {
    }
    
}
