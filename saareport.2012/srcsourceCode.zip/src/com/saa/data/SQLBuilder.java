/*
 * SQLBuilder.java
 *
 * Created on April 10, 2007, 2:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.data;

/**
 *
 * @author Administrator
 */
public class SQLBuilder {
    
    /** Creates a new instance of SQLBuilder */
    private static String user  ="'jrx'";
    private static String EXECUTE_PROCEDURE = "execute procedure\t";
    private static String sp_x_monthly_close = "x_monthly_close\t";
    private SQLBuilder() {
    }
    
    /*@return treemenu sql select */
    public static String getTreeMenuSelect(){
        StringBuffer  sb = new StringBuffer() ;
       sb.append("SELECT FORM_caption as ChildName,\n");
       sb.append("MENU_INDEX as Node,\n");
       sb.append("FORM_NAME  as NodeAction,\n");
       sb.append("MENU_ITEM_INDEX as ChildNode,\n");
       sb.append("MAIN_MENU_NAME as RootName,\n");
       sb.append("history_caption as ResourceName\n");
       sb.append("from sys_menus where MODULE_ID = 'JRX'\n");
       sb.append("AND ENABLED = 'Y'\n");
       sb.append("order by MAIN_MENU_NAME,MENU_INDEX,MENU_ITEM_INDEX");
       return sb.toString();
    }
    
    public static String getTreeNodeSelect(){
          StringBuffer  sb = new StringBuffer() ;    
          sb.append("select distinct  MENU_INDEX as Node,\n");
          sb.append("MAIN_MENU_NAME as RootName\n");
          sb.append("from sys_menus where update_user = 'jrx'\n");
          sb.append("order by MENU_INDEX\n");
          return sb.toString();
    }
    
    public static String getMontylyCloseExecute(Object[] params){
       StringBuffer  sb = new StringBuffer() ;
       sb.append(EXECUTE_PROCEDURE);
       sb.append(sp_x_monthly_close);
       sb.append(params[0].toString());
       sb.append(",");
       sb.append(params[1].toString());
       sb.append(",");
       sb.append(user);
       return sb.toString(); 
    }
    
    public static String getLoginValidExecute(Object[] params){
        StringBuffer sb = new StringBuffer();
        sb.append("select count(*) as rows from sys_users\n");
        sb.append("where user_id='"+params[0].toString()+"'\n");
        sb.append("and current_password='"+params[1].toString()+"'");
        return sb.toString();
              
    }
    public static String getAvaliableLots(){
            //    
    //    SELECT  distinct lot_cd as purchase_no
    //FROM   ic_stockcard
    //WHERE DOC_DATE <=  current_timestamp
    //AND GROUP_ID NOT IN ('SG009','SG008')
    //AND PURCHASE_DATE >= '01/01/2006'
    //GROUP BY STOCK_CD,GROUP_ID,UOM_CD,LOT_CD,PURCHASE_DATE,ACCT_CD,REF_NO,REF_DATE
    //HAVING SUM(QTY) > 0
        StringBuffer sb = new StringBuffer();
        sb.append("SELECT  distinct lot_cd as purchase_no\n");
        sb.append("FROM   ic_stockcard\n");
        sb.append("WHERE DOC_DATE <=  current_timestamp\n");
        sb.append("GROUP BY STOCK_CD,GROUP_ID,UOM_CD,LOT_CD,PURCHASE_DATE,ACCT_CD,REF_NO,REF_DATE\n");
        sb.append("HAVING SUM(QTY) > 0");
        return sb.toString();
    }
    
    
    public static String getAvaliableGRNNO(){
//     SELECT DISTINCT GRN_NO
//  FROM PO_GRN_HD
//  WHERE STATUS <>'X'
        StringBuffer sb = new StringBuffer();
        sb.append("SELECT DISTINCT GRN_NO\n");
        sb.append("FROM PO_GRN_HD\n");
        sb.append("WHERE STATUS <>'X'\n");
        return sb.toString();
    }
    /*quotation*/
    public static String getAvalibleQuote(){
    	StringBuffer sb = new StringBuffer();
    	sb.append("select doc_no from so_quotation_hd where status ='A'");
    	return sb.toString();
    }
    /*Aor*/
    public static String getAvalibleAOR(){
    	StringBuffer sb = new StringBuffer();
    	sb.append("select order_no from so_order_hd where status ='A'");
    	return sb.toString();
    }
    
    public static String getAvaliableDeliveryNo(){
         StringBuffer sb = new StringBuffer();
        sb.append("SELECT DISTINCT delivery_no\n");
        sb.append("FROM so_det_hd\n");
        sb.append("WHERE STATUS <>'X'\n");
        return sb.toString();
    }
    /*pc util functions*/
    public static String getAvaliablePCOrderNo(){
        StringBuffer sb = new StringBuffer();
        sb.append("select ORDER_NO from po_order_hd\n");
       	sb.append("where status ='A'");
    	return sb.toString();
    }
    /*pc*/
    /**@return 
        execute procedure X_GET_MELT_SUMMARY  '01M04','04M04' '@fromMelt' , '@toMelt'
     *@param fromMelt String 
     *@param toMelt String 
     *
     */
    public static String getMeltSheetSummary(String fromMelt , String toMelt){
        String s = EXECUTE_PROCEDURE +" X_GET_MELT_SUMMARY "+quotedString(fromMelt)+","+quotedString(toMelt);
        return s;
    }
    
    public static String quotedString(String value){
        return "'"+value+"'";
    }
   
   

  
    
}
