/*
 * InterfaceData.java
 *
 * Created on April 4, 2007, 4:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.data;

/**
 *
 * @author Administrator
 */
public interface InterfaceData {
    public String getReportID();
    
}
