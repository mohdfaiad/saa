/*
 * Actions.java
 *
 * Created on April 10, 2007, 1:19 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.data;

/**
 *
 * @author Administrator
 */
public class Actions {
    
    /** Creates a new instance of Actions */
    /*relate to awt action perform*/
    public static String NONE_ACTION    =   "NONE";
    public static String PROCESS_ACTION =   "PROCESS";
    public static String REPORT_ACTION  =   "REPORT";
    public  Actions() {
    }
    
}
