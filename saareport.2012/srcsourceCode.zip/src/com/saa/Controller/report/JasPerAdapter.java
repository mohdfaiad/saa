/*
 * JasPerAdapter.java
 *
 * Created on 21 ����¹ 2550, 13:50 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.Controller.report;

import com.saa.Controller.*;
import com.saa.Utils.MessageDlg;
import com.saa.Utils.SystemConfig;
import com.saa.data.ReportOptions;
import com.saa.logger.AppLogger;
import com.saa.main.RunTimeController;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.OutputStream;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.view.JasperViewer;
import java.util.Map;
import java.sql.Connection;
import java.sql.Timestamp;

import org.eclipse.jdt.internal.compiler.parser.JavadocParser;

public abstract class JasPerAdapter implements JasperReportInterface {
	private static String PARAM_SYSDATE =  "pSysDate";
	private static String PARAM_UID = "pUID";

    private static RunTimeController runtimeControl = RunTimeController.getRuntimeController();
    private Connection con;
    protected String RESOURCE_DIRECTORY ="/report/templates/";
    protected String OUTPUT_DIRECTORY   ="/report/output/";
    protected String reportSource       ="";
    protected String reportDest         ="";
    private String TEMPLATE_DIR       = "";
    private String OUTPUT_DIR         =""; 
    public java.util.Map  reportparams = new java.util.HashMap();
    public JRParameter[] jrParam = null;
    /*default option is preview*/
    private int exportOption = 0;
    
    
    protected AppLogger log = AppLogger.getLogger();
    
    protected JasperReport jasperReport;
    protected JasperPrint jasperPrint;
    
    /** Creates a new instance of JasPerAdapter */
    private JasPerAdapter() {
    }
  
    public JasPerAdapter(String resourceName , int option){
        reportSource = resourceName;
        exportOption = option;
        con = runtimeControl.getDBManager().getConnection();
        setTemplateDir();
    }
    public String getTemplateDir(){
        return TEMPLATE_DIR;
    }
    public void setTemplateDir(){
        File f = null;
        try{
        f = new File(SystemConfig.getWorkingDirectory()+RESOURCE_DIRECTORY);
        OUTPUT_DIR = SystemConfig.getWorkingDirectory()+OUTPUT_DIRECTORY;
        }catch(Exception e){
            log.warning(e.getMessage());
        }
        try{
        
           TEMPLATE_DIR = f.getCanonicalPath();
           log.info("Report Adapter get Default Dir :"+TEMPLATE_DIR);
        }catch(Exception ex){
            log.warning("Directory format error"+TEMPLATE_DIR+" Ex="+ex.getMessage());
        }
     //  return TEMPLATE_DIR;
    }
    
    public void setExportOption(int opt){
        exportOption = opt;
    }
    /*this support to set current date time to anywhere of "pSysDate" displayed*/
    public void processSystemParameters(){
    	for(int i =0; i <jrParam.length; i++){
    		if (jrParam[i].getName().equals(PARAM_SYSDATE)){
    			reportparams.put(PARAM_SYSDATE, new Timestamp(System.currentTimeMillis()));
    			
    		}else if(jrParam[i].getName().equals(PARAM_UID)){
    			reportparams.put(PARAM_UID, runtimeControl.getLoggedUser());
    			
    		}
    	}
   
    	
    }
    public void loadReport(){
        try{
            jasperReport = JasperCompileManager.compileReport(TEMPLATE_DIR+"/"+reportSource);
            //   processParameters(reportparams);
            jrParam = jasperReport.getParameters();
            processSystemParameters();
            jasperPrint = JasperFillManager.fillReport(
                    jasperReport, reportparams, con);
            exportReport(exportOption);
        } catch(JRException ex){
        	log.severe(ex.getMessage());
            ex.printStackTrace();
        }
    }
    public void setParameters(java.util.Map  params){
        reportparams =  params;
    }
    public abstract void processParameters(java.util.Map  params);
    
    public void exportReport(int option){
       String title="";
        switch(option){
            case 0:
                /*used overload viewReport with exitOnClose = false do not close application after close preview*/
                JasperViewer.viewReport(jasperPrint,false);
                break;
            case 1:
            
                try{
                    reportDest =OUTPUT_DIR+reportSource+ReportOptions.ExportExtension.HTML;
                    title ="HTML";
                    JasperExportManager.exportReportToHtmlFile(jasperPrint,reportDest);
                }catch(JRException ex){
                    ex.printStackTrace();
                }
              
                break;
                //EXCEL
            case 2:
                try{
                    reportDest =OUTPUT_DIR+reportSource+ReportOptions.ExportExtension.XLS; 
                     title ="XLS";
                    JRXlsExporter exporterXls = new JRXlsExporter ();
                    exporterXls.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
                    exporterXls.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, 
                                                            reportDest);
                    exporterXls.exportReport();


                }catch(JRException ex){
                    ex.printStackTrace();
                }
                break;
                
            case 3:
                try{
                    reportDest =OUTPUT_DIR+reportSource+ReportOptions.ExportExtension.RTF;
                    title ="RTF";
                    JRRtfExporter exporter = new JRRtfExporter();
                    exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
                    exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, reportDest);
                    exporter.exportReport();    
                }catch(JRException ex){
                    ex.printStackTrace();
                }
                break;
                //PDF
            case 4:
                try{
                   reportDest =OUTPUT_DIR+reportSource+ReportOptions.ExportExtension.PDF;
                   title ="PDF";
                    JasperExportManager.exportReportToPdfFile(jasperPrint,reportDest);
                }catch(JRException ex){
                    ex.printStackTrace();
                }
                break;
            default:break;
        }
        //preview not shown message dlg
        if (option > 0)
          MessageDlg.info(null,"Export Data to "+reportDest+" Completed", title+" Export Completed");
    }
    
    
}
