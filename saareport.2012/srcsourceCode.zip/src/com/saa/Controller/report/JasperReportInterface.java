/*
 * JasperReportInterface.java
 *
 * Created on 21 ����¹ 2550, 13:59 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.Controller.report;

/**
 *
 * @author Administrator
 */
public interface JasperReportInterface {
    
     public void loadReport();
     public void processParameters(java.util.Map  params);
    
}
