/*
 * ControllerInterface.java
 *
 * Created on April 3, 2007, 7:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.Controller;

/**
 *
 * @author Administrator
 */
/*base controller */
public interface ControllerInterface {
    public void init();
    public void destroy();
    public void process();
    
}
