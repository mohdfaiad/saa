/*
 * TreeActionListener.java
 *
 * Created on April 20, 2007, 12:53 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.Controller;

/**
 *
 * @author Administrator
 */
public interface TreeActionListener {
    public void actionPerformed(Object object);
    
}
