/*
 * WH007Frame.java
 *
 * Created on 30 ����¹ 2550, 15:36 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.wh;

import com.saa.data.SQLBuilder;
import com.saa.data.SubTreeObject;
import com.saa.ui.View.BaseReportFrame;
import com.saa.ui.View.BaseView;
import com.saa.data.ui.*;
import com.saa.Utils.*;
import com.saa.ui.View.panels.AbstractComboPanel;
import com.saa.ui.View.panels.DateFromToPanel;
import com.saa.ui.View.panels.DatePanel;
import com.saa.ui.View.panels.YearMonthPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;
public class WH007Frame  extends BaseReportFrame {
    
    /** Creates a new instance of WH008Frame */
	DateFromToPanel dateRangePanel;
    public  WH007Frame(SubTreeObject node , int w , int h){
      super(node,w,h);
      dateRangePanel = (DateFromToPanel)decorator.getDateFromToPanel("From :", "To :");
      centerPanel.add(dateRangePanel,BorderLayout.CENTER);
      pack();
      setVisible(true);
      
   }
   
      public void processParameters(){
         params.put("pSDate",dateRangePanel.getDate(""));
         params.put("pEDate",dateRangePanel.getEndDate());
         params.put("pSysDate", new Timestamp(System.currentTimeMillis()));
    }
    
}
