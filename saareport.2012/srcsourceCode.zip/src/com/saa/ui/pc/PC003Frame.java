/*
 * WH001Frame.java
 *
 * Created on 21 ����¹ 2550, 15:29 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.pc;
import com.saa.Controller.report.ReportsController;
import com.saa.data.SubTreeObject;
import com.saa.ui.View.BaseReportFrame;
public class PC003Frame extends PC002Frame{
  public  PC003Frame(SubTreeObject node , int w , int h){
      super(node,w,h);
  }
  
      
}
