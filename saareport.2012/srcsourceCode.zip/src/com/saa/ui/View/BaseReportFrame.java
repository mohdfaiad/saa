/*
 * BaseReportFrame.java
 *
 * Created on 25 ����¹ 2550, 12:38 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.View;
import com.saa.Controller.report.ReportsController;
import com.saa.data.ReportOptions;
import com.saa.data.SQLBuilder;
import com.saa.data.SubTreeObject;
import com.saa.logger.AppLogger;
import com.saa.ui.Dialogs.ProgressDialog;
import com.saa.ui.View.BaseView;
import com.saa.data.ui.*;
import com.saa.Utils.*;
import com.saa.ui.View.panels.ExportOptionsPanel;
import com.saa.ui.View.panels.YearMonthPanel;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
public abstract class BaseReportFrame extends BaseView{
    
    /** Creates a new instance of BaseReportFrame */
    protected ExportOptionsPanel exportPanel;
    protected ReportsController controller;
    protected JPanel centerinnerPanel;
    protected  Map params = new HashMap();
    protected AppLogger logger = AppLogger.getLogger();
    protected ProgressDialog progressDlg = null;
    protected boolean success = false;
    protected Cursor hourGlassCursor = new Cursor(Cursor.WAIT_CURSOR);
    protected Cursor defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);

    public BaseReportFrame(SubTreeObject node , int w , int h) {
        super(node,w,h);
        
        centerPanel.setLayout(new BorderLayout());
        centerinnerPanel = new JPanel();
        
        exportPanel = (ExportOptionsPanel)decorator.getExportOptionsPanel();
        centerinnerPanel.add(exportPanel,BorderLayout.SOUTH);
       // centerPanel.add(new JPanel(),BorderLayout.SOUTH);
        centerPanel.add(centerinnerPanel,BorderLayout.SOUTH);
        //centerPanel.add(new JPanel(),BorderLayout.PAGE_END);
       
        //  getContentPane().add(decorator.getExportOptionsPanel() );
        pack();
        setVisible(true);
        
        
    }
    public abstract void processParameters();
   
    public  boolean validateInput(){
        success = true;
        return true;
    }
    public void actionPerformed(ActionEvent e) {
       super.actionPerformed(e);
       if (e.getActionCommand().equals(decorator.buttonsCommand[decorator.CMD_OK])){
         try {
            this.setCursor(hourGlassCursor);
             logger.info("Loading report.."+actionObject.getResourceName()); 
             setProgress(10);
             SwingUtilities.invokeLater(new Runnable() {
               public void run() {
            	   setProgress(25);
            	    pack();
                    controller = new ReportsController(actionObject.getResourceName(),exportPanel.exportOptionsCombo.getSelectedIndex());
                    setProgress(30);
                    pack();
                    if (validateInput()){
                        if (success ) {
                            processParameters();
                            controller.setParameters(params) ;
                            setProgress(60);
                            pack();
                            logger.info("Setting params.."+actionObject.getResourceName()); 
                            setProgress(100);
                            pack();
                            if (success ) controller.loadReport();
                       }else{
                            showError("Invalid operation process has canceled");
                                  setProgress(0);
                        }
                    }else{
                        showError("Invalid Input parameters");
                        setProgress(0);
                 
                    }
               }
            });
            
        }finally{
        	this.setCursor(defaultCursor);
           // progressDlg.setVisible(false);
        }
    }
    }
    protected void showError(String msg){
        MessageDlg.warning(this,msg,"");
    }
    protected void showSuccess(String msg){
        MessageDlg.info(this,msg,"");
    }
}





