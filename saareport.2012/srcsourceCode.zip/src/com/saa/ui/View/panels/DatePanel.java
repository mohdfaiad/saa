/*
 * DatePanel.java
 *
 * Created on 30 ����¹ 2550, 9:52 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.View.panels;

import com.saa.ui.date.DateField;
import com.saa.ui.date.DatePicker;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.util.Date;


/**
 *
 * @author Administrator
 */
public class DatePanel extends BasePanel{
    
    /** Creates a new instance of DatePanel */
    public JLabel dateLable;
    public DateField dateField;
    public DatePanel(String msg) {
        setLayout(new FlowLayout());
        dateLable =  new JLabel(msg);
        add(dateLable);
        dateField = new DateField();
        add(dateField);
       // pack();
      //  dp.setHideOnSelect(false);
      // dlg.getContentPane().add(dp);
    }
    
    public Date getDate(String format){
    
  //  SimpleDateFormat sdf = new SimpleDateFormat(format);
   
 //   System.out.println(sdf.format( dateField.getDate()));
    //sdf.format()

        return dateField.getDate();
    }
    
}
