/*
 * BasePanel.java
 *
 * Created on April 24, 2007, 10:22 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.View.panels;

import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author Administrator
 */
public class BasePanel extends JPanel {
    
    /** Creates a new instance of BasePanel */
    public BasePanel() {
        super();
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK));

    }
    
}
