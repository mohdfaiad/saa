package com.saa.ui.View.panels;

import java.util.Date;

import javax.swing.JLabel;

import com.saa.ui.date.DateField;

public class DateFromToPanel extends DatePanel {
	public DateField dateEnd = new DateField();
	public DateFromToPanel(String msg , String msg1){
		super(msg);
		add(new JLabel(msg1));
		add(dateEnd);
		repaint();
		
	}	
	public Date getEndDate(){
		return dateEnd.getDate();
	}

}
