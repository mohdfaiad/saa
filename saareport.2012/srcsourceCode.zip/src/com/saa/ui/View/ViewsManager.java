/*
 * ViewsManager.java
 * responsibility to return any spacifi
 * Created on April 20, 2007, 1:39 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.View;

/**
 *
 * @author Administrator
 */

import com.saa.ui.pc.PC001Frame;
import com.saa.ui.pc.PC002Frame;
import com.saa.ui.pc.PC003Frame;
import com.saa.ui.pn.PN001Frame;
import com.saa.ui.pn.PN002Frame;
import com.saa.ui.pn.PN006Frame;
import com.saa.ui.pn.PN012Frame;
import com.saa.ui.sa.SA001Frame;
import com.saa.ui.sa.SA002Frame;
import com.saa.ui.sa.SA003Frame;
import com.saa.ui.sa.SA004Frame;
import com.saa.ui.wh.MonthCloseFrame;
import com.saa.ui.wh.WH001Frame;
import com.saa.ui.wh.WH002Frame;
import com.saa.ui.wh.WH003Frame;
import com.saa.ui.wh.WH004Frame;
import com.saa.ui.wh.WH005Frame;
import com.saa.ui.wh.WH006Frame;
import com.saa.ui.wh.WH007Frame;
import com.saa.ui.wh.WH008Frame;
import com.saa.ui.wh.WH009Frame;
import com.saa.ui.wh.WH010Frame;
import javax.swing.JFrame;
import com.saa.data.*;
import javax.swing.SwingUtilities;

public class ViewsManager {
	private static ViewsManager vm;

	/** Creates a new instance of ViewsManager */
	/*Indicate main system
	 *1.Warehouse
	 *2.Purchase
	 *3.Production
	 *4.Sale
	 */
	private static int mainIDX = -1;

	/*indicate submain item
	 *for instance:
	 *mainIDX 1 SubIDX 0 will return Monthly close frame
	 */
	private static int subIDX = -1;

	/*current frame instance*/
	protected static BaseView currentFrame = null;

	private JFrame parrentFrame = null;

	private ViewsManager(JFrame frame) {
		parrentFrame = frame;
	}

	public static ViewsManager getViewManager(JFrame frame) {
		if (vm == null) {
			vm = new ViewsManager(frame);
			return vm;
		}
		return vm;
	}

	public BaseView getView(final SubTreeObject node) {
		mainIDX = node.getLevel();
		subIDX = node.getSubLevel();
		switch (mainIDX) {
		case 1:

			switch (subIDX) {
			case 0:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						currentFrame = new MonthCloseFrame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);

					}
				});

				break;
			//currentFrame.setLocationRelativeTo()

			case 1:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH001Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});

				break;
			case 2:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH002Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 3:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH003Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});

				break;
			case 4:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH004Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 5:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH005Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 6:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH006Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 7:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH007Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;

			case 8:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH008Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 9:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH009Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
			case 10:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new WH010Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;
				default:break;
		
		}
	
		case 2: //Purchase order
		switch (subIDX) {
			case 1:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new PC001Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});

				break;
			case 2:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new PC002Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;

			case 3:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new PC003Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
			break;
			default:
				break;
			}
			break;
		//PN Product Plan
		case 3:
			switch (subIDX) {
			/*delivery order frame*/
			case 1:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						currentFrame = new PN001Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);

					}
				});

				break;
			/*melt summary*/
			case 2:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						currentFrame = new PN002Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);

					}
				});
				break;
			//melt sheet 
			case 6:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						currentFrame = new PN006Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);

					}
				});
				break;
			case 12:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						currentFrame = new PN012Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);

					}
				});
				break;


			}
			break;
		case 4:
			switch (subIDX) {
			case 1:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new SA001Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});

				break;
			case 2:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new SA002Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;

			case 3:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new SA003Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
			 break;
			case 4:
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {

						currentFrame = new SA004Frame(node, 500, 500);
						currentFrame.setParrent(parrentFrame);
					}
				});
				break;

			default:
				break;
			}
			break;
		default:
			break;
		}
		return currentFrame;
	}

}
