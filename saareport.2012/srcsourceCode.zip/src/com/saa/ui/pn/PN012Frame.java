/*
 * PN001Frame.java
 *
 * Created on 7 ����Ҥ� 2550, 15:28 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.pn;


import com.saa.Controller.report.ReportsController;
import com.saa.data.SQLBuilder;
import com.saa.data.SubTreeObject;
import com.saa.ui.View.BaseReportFrame;
import com.saa.ui.View.BaseView;
import com.saa.data.ui.*;
import com.saa.Utils.*;
import com.saa.ui.View.panels.AbstractComboPanel;
import com.saa.ui.View.panels.DatePanel;
import com.saa.ui.View.panels.YearMonthPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class PN012Frame extends BaseReportFrame{
   DatePanel datePanel;


   public  PN012Frame(SubTreeObject node , int w , int h){
      super(node,w,h);
      datePanel = (DatePanel)decorator.getDateFieldPanel("AsDate:");
      centerPanel.add(datePanel,BorderLayout.CENTER);
      pack();
  }
    public void processParameters(){
         params.put("pEndDate",datePanel.getDate(""));
         //params.put("pEDate",endDatePanel.getDate(""));
    }
    
}
