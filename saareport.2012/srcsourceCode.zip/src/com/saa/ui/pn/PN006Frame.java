package com.saa.ui.pn;



import com.saa.data.SubTreeObject;


public class PN006Frame extends PN002Frame {
	
	 public  PN006Frame(SubTreeObject node , int w , int h){
	      super(node,w,h);
	     subReportName = "\\PNSUB004.jasper";
	  }

}
