/*
 * ModalResult.java
 *
 * Created on 25 ����¹ 2550, 16:54 �.
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.ui.Dialogs;

/**
 *
 * @author Administrator
 */
public class ModalResult {
    
    /** Creates a new instance of ModalResult */
    
    public static int MR_OK     =   1;
    public static int MR_CANCEL  =  0;
    public static int MR_EXIT  = -1;
    private ModalResult() {
    }
    
    
    
}
