/*
 * AppLogger.java
 *
 * Created on April 3, 2007, 3:14 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.saa.logger;

/**
 *
 * @author Administrator
 */

import java.io.File;
import java.io.IOException;
import java.util.logging.*;
import com.saa.Utils.SystemConfig;
public class AppLogger {
	    /*log file name*/
	    private static AppLogger servicelogger;
	    private static Logger logger = Logger.getAnonymousLogger();
	    private final static String fileName = "/logs/service.log";
            private Level level = Level.ALL;
	    /*avoid new operator*/
	    private AppLogger(){
	    	try
	    	{
	    	FileHandler handler = new FileHandler(SystemConfig.getWorkingDirectory()+fileName);
	    	handler.setFormatter(new SimpleFormatter());
	    	logger.addHandler(handler);
                logger.info("Created log "+SystemConfig.getWorkingDirectory()+fileName);
	    	}catch(IOException e){
	    		e.printStackTrace();
	    	}
	    }
	    /*singleton creator */
	    public static AppLogger getLogger(){
	    	if (servicelogger == null){
	    		servicelogger = new AppLogger();
	    		return servicelogger;
	    	}
	    
	    	return servicelogger;
	    }
	    /** log a severe message */
	    public void severe(String msg){
			log(Level.SEVERE, msg);
	    }

	    /** log a warning message */
	    public void warning(String msg){
			log(Level.WARNING, msg);
	    }

	    /** log a info message */
	    public void info(String msg){
			log(Level.INFO, msg);
	    }

	    /** log a fine message */
		public void fine(String msg){
			log(Level.FINE, msg);
	    }

	    /** log a finer message */
		public void finer(String msg){
			log(Level.FINER, msg);
	    }

	    /** log a finest message */
		public void finest(String msg){
			log(Level.FINEST, msg);
	    }

	    /** log a config message */
		public void config(String msg){
			log(Level.CONFIG, msg);
	    }

	    /** do the logging */
	    private void log(Level level, String msg){
		   logger.log(level,msg);
	    }

	    /** log an exception */
		public void log(Level level, String msg, Throwable e){
			log(level, msg);
	    }

	    /**
	     * Allows a log message to pass along an arbitrary parameter.
	     * Implemented by Java logging already, we're using this to enable
	     * the performance logging.<p>
	     *
	     * NOTE: The arbitrary parameter is ignored by this implementation.
	     */
		public void log(Level level, String msg, Object obj){
	        log(level, msg);
	    }

	    /** log an exception */
		public void logException(Throwable e){
			this.log(Level.SEVERE, e.getMessage(), e);
		}


	    /** set the logging level */
	    public void setLevel(Level level){
			this.level = level;
	    }

	  

	    /** get the output type */
	    public int getOutputType(){
	        // Not implemented
	        return 0;
	    }

	 

	
	  
	   		
	

}
